class ChatModel {
  bool? isuser;
  String? message;

  ChatModel({this.isuser, this.message});

  ChatModel.fromJson(Map<String, dynamic> json) {
    isuser = json['isuser'];
    message = json['message'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['isuser'] = isuser;
    data['message'] = message;
    return data;
  }

}
