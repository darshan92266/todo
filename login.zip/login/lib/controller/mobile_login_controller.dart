import 'dart:developer';

import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:login/screens/payment_getway_screen.dart';

class MobileLoginController extends GetxController {
  Rx<TextEditingController> mobileSignUpController = TextEditingController().obs;
  FirebaseAuth auth = FirebaseAuth.instance;
  RxString verificationId = ''.obs;
  RxString authStatus = "".obs;
  RxString otp = "".obs;
  RxBool otpView = false.obs;
  RxString countryCode = ''.obs;

  Future<void> verifyPhoneNumber() async {
    await FirebaseAuth.instance.verifyPhoneNumber(
      phoneNumber: '+${countryCode.value}${mobileSignUpController.value.text}',
      timeout: const Duration(seconds: 40),
      verificationCompleted: (AuthCredential authCredential) {
        auth.signInWithCredential(authCredential);
      },
      verificationFailed: (FirebaseAuthException authException) {
        if (authException.code == 'invalid-phone-number') {
          authStatus.value = "invalid phone number";
          log("invalid-phone-number");
          Get.snackbar("Error....!", "Please Enter valid mobile no");
        } else {
          authStatus.value = "Problem when send the code";
          log("Problem when send the code");
          Get.snackbar("Something went Wrong....!", 'problem when send the code');
        }
      },
      codeSent: (String verificationId, int? resendToken) {
        this.verificationId.value = verificationId;
        authStatus.value = "OTP has been successfully send";
        Get.snackbar("Alert.....!", 'OTP has been successfully send');
        log("OTP has been successfully send");
        otpView.value = true;
      },
      codeAutoRetrievalTimeout: (String verificationId) {
        this.verificationId.value = verificationId;
        authStatus.value = "TIMEOUT";
        log("TIMEOUT");
        otpView.value ? null : Get.snackbar("Alert.....!", 'OTP has been Expired....');
      },
    );
  }

  Future<void> signIn(String otp) async {
    try {
      PhoneAuthCredential credential = PhoneAuthProvider.credential(verificationId: verificationId.value, smsCode: otp);
      await auth.signInWithCredential(credential);
      // ignore: unnecessary_null_comparison
      if (credential != null) {
        authStatus.value = "Your account is successfully verified";
        log("Your account is successfully verified");
        Get.snackbar("Verified Successful....!", "Login Successful");
        Get.off(const PaymentGatewayScreen());
        print('===============verificationCompleted');
      } else {
        Get.snackbar("Error ", 'Something went Wrong....!');
      }
    } catch (e) {
      log(e.toString());
      Get.snackbar("Something went Wrong....!", 'Please check and enter the correct verification code again');
    }
  }
}
