import 'dart:io';
import 'dart:developer';

import 'package:get/get.dart';
import 'package:image_picker/image_picker.dart';
import 'package:permission_handler/permission_handler.dart';

class VideoUploadController extends GetxController{
  ImagePicker picker = ImagePicker();
  Rx<File> file = File("").obs;
  PermissionStatus? permissionStatus;
  RxBool isDownloading=false.obs;

  Future uploadToStorage() async {
    try {
      final DateTime now = DateTime.now();
      final int millSeconds = now.millisecondsSinceEpoch;
      final String month = now.month.toString();
      final String date = now.day.toString();
      final String storageId = (millSeconds.toString());
      final String today = ('$month-$date');

      await picker.pickVideo(source: ImageSource.gallery).then((value){
        log(value!.path.toString());
        file.value = File(value.path.toString());
        log(file.value.toString());
      });
    //
    //   Reference ref = FirebaseStorage.instance.ref().child("video").child(today).child(storageId);
    //   UploadTask uploadTask = ref.putFile(file.value, StorageMetadata(contentType: 'video/mp4'));
    //
    // final String url = downloadUrl.toString();
    //
    // print(url);

    } catch (error) {
    print(error);
    }

  }

  @override
  Future<void> onInit() async {
    permissionStatus = await Permission.storage.status;

    if (permissionStatus != PermissionStatus.granted) {
      PermissionStatus permissionStatus = await Permission.storage.request();
      permissionStatus = permissionStatus;
    }
    super.onInit();
  }
}