import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:login/screens/payment_getway_screen.dart';

class EmailLoginController extends GetxController {
  Rx<TextEditingController> emailController = TextEditingController().obs;
  Rx<TextEditingController> passwordController = TextEditingController().obs;

  submit() async {
    if (emailController.value.text.isEmail) {
      if (passwordController.value.text.length == 8) {
        try {
          await FirebaseAuth.instance.signInWithEmailAndPassword(email: emailController.value.text, password: passwordController.value.text).then((value) {
            Get.snackbar("Successful....!", "Sign Up Successful");
            Get.off(const PaymentGatewayScreen());
          });
        } on FirebaseAuthException catch (e) {
          if (e.code == 'user-not-found') {
            Get.snackbar("Something went Wrong....!", "No user found for that email.");
            print('No user found for that email.');
          } else if (e.code == 'wrong-password') {
            Get.snackbar("Something went Wrong....!", "Wrong password for this user.");
            print('Wrong password provided for that user.');
          }
        } catch (e) {
          print("===========" + e.toString());
        }
      } else {
        Get.snackbar("Please Enter Valid Password", "password must be 8 character");
      }
    } else {
      Get.snackbar("Please check Email", "Please Enter valid Email");
    }
  }
}
