import 'dart:convert';
import 'dart:developer';

import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter_dotenv/flutter_dotenv.dart';
import 'package:flutter_stripe/flutter_stripe.dart';
import 'package:get/get.dart';

// ignore: depend_on_referenced_packages
import 'package:http/http.dart' as http;

class PaymentGatewayController extends GetxController {
  RxBool isLogin = true.obs;
  Map<String, dynamic>? paymentIntent;

  Future<void> stripeMakePayment({required String amount}) async {
    log(double.parse(amount).toStringAsFixed(0));
    try {
      Map<String, dynamic>? paymentIntentData = await createStripeIntent(amount: amount);
      if (paymentIntentData!.containsKey("error")) {
        Get.back();
        Get.snackbar("Error...", "Something went wrong, please contact admin.");
      } else {
        await Stripe.instance.initPaymentSheet(
            paymentSheetParameters: SetupPaymentSheetParameters(
                paymentIntentClientSecret: paymentIntentData['client_secret'],
                allowsDelayedPaymentMethods: false,
                googlePay: const PaymentSheetGooglePay(
                  merchantCountryCode: 'IN',
                  testEnv: true,
                  currencyCode: "USD",
                ),
                style: ThemeMode.system,
                appearance: const PaymentSheetAppearance(
                  colors: PaymentSheetAppearanceColors(
                    primary: Colors.lightBlue,
                  ),
                ),
                merchantDisplayName: 'GoRide'));
        displayStripePaymentSheet(amount: amount);
      }
    } catch (e, s) {
      log("$e \n$s");
      Get.snackbar("Error...", "exception:$e \n$s");
    }
  }

  displayStripePaymentSheet({required String amount}) async {
    try {
      // var responseValue = await Stripe.instance.presentPaymentSheet();
      log("Success >>>>>>>...");
      Get.back();
      Get.snackbar("Successfully Done...!", "Payment successfully");
    } on StripeException catch (e) {
      Get.back();
      // var lo1 = jsonEncode(e);
      // var lo2 = jsonDecode(lo1);
      // StripePayFailedModel lom = StripePayFailedModel.fromJson(lo2);
      // Get.snackbar("Error...", lom.error.message);
      Get.snackbar("Error...", e.toString());
      log("Error >>>>>>>...$e");
    } catch (e) {
      Get.back();
      Get.snackbar("Error...", e.toString());
      log("Error...$e");

    }
  }

  createStripeIntent({required String amount}) async {
    try {
      Map<String, dynamic> body = {
        'amount': ((double.parse(amount) * 100).round()).toString(),
        'currency': "USD",
        'payment_method_types[]': ['card'],
        "description": "Strip Payment",
        "shipping[name]": "Vinit",
        "shipping[address][line1]": "",
        "shipping[address][postal_code]": "",
        "shipping[address][city]": "",
        "shipping[address][state]": "",
        "shipping[address][country]": "",
      };
      var stripeSecret = 'sk_test_51NBEXtSC0Lwy8Mt75KF44NGs8pkPuAqpo3iAkIdXENVio9bi4QKA4lY4YGKCuVrdZckZKuGkZHeB4TBetTkrvfuU00FXwH9laC';
      var response = await http.post(Uri.parse('https://api.stripe.com/v1/payment_intents'),
          body: body, headers: {'Authorization': 'Bearer $stripeSecret', 'Content-Type': 'application/x-www-form-urlencoded'});

      return jsonDecode(response.body);
    } catch (e) {
      log(e.toString());
    }
  }

  displayPaymentSheet(context) async {
    try {
      await Stripe.instance.presentPaymentSheet().then((value) {
        showDialog(
            context: context,
            builder: (_) => const AlertDialog(
                  content: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Icon(
                        Icons.check_circle,
                        color: Colors.green,
                        size: 100.0,
                      ),
                      SizedBox(height: 10.0),
                      Text("Payment Successful!"),
                    ],
                  ),
                ));

        paymentIntent = null;
      }).onError((error, stackTrace) {
        throw Exception(error);
      });
    } on StripeException catch (e) {
      if (kDebugMode) {
        print('Error is:---> $e');
      }
      const AlertDialog(
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Row(
              children: [
                Icon(
                  Icons.cancel,
                  color: Colors.red,
                ),
                Text("Payment Failed"),
              ],
            ),
          ],
        ),
      );
    } catch (e) {
      if (kDebugMode) {
        print('$e');
      }
    }
  }

  createPaymentIntent(String amount, String currency) async {
    try {
      //Request body
      Map<String, dynamic> body = {
        'amount': calculateAmount(amount),
        'currency': currency,
      };

      //Make post request to Stripe
      var response = await http.post(
        Uri.parse('https://api.stripe.com/v1/payment_intents'),
        headers: {'Authorization': 'Bearer ${dotenv.env['STRIPE_SECRET']}', 'Content-Type': 'application/x-www-form-urlencoded'},
        body: body,
      );
      return json.decode(response.body);
    } catch (err) {
      throw Exception(err.toString());
    }
  }

  calculateAmount(String amount) {
    final calculatedAmout = (int.parse(amount)) * 100;
    return calculatedAmout.toString();
  }

  @override
  void onInit() {
    Stripe.publishableKey = 'pk_test_51NBEXtSC0Lwy8Mt7tt8qu2DThcirEhbqx9SHeAgzmyUzjCyDvTgEQOvvMzwWA8j277ZOzY6956JWpEiQJFyW3OiC002Rf2nu1w';
    Stripe.merchantIdentifier = 'GoRide';
    Stripe.instance.applySettings();
    super.onInit();
  }
}
