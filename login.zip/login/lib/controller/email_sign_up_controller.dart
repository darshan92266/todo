import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:login/screens/email_login_screen.dart';

class EmailSignUpController extends GetxController {
  Rx<TextEditingController> emailSignUpController = TextEditingController().obs;
  Rx<TextEditingController> passwordSignUpController = TextEditingController().obs;

  submit() async {
    if (emailSignUpController.value.text.isEmail) {
      try {
        await FirebaseAuth.instance
            .createUserWithEmailAndPassword(email: emailSignUpController.value.text, password: passwordSignUpController.value.text)
            .then((value) => {Get.snackbar("Successful....!", "Sign Up Successful"), Get.to(const EmailLoginScreen())});
      } on FirebaseAuthException catch (e) {
        if (e.code == 'weak-password') {
          Get.snackbar("Something went Wrong....!", "The password provided is too weak.");
          print('============The password provided is too weak.');
        } else if (e.code == 'email-already-in-use') {
          Get.snackbar("Something went Wrong....!", "The account already exists for this email.");
          print('==============The account already exists for that email.');
        }
      } catch (e) {
        print("===========" + e.toString());
      }
    } else {
      Get.snackbar("Please check Email", "Please Enter valid Email");
    }
  }
}
