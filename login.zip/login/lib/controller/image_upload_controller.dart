import 'dart:developer';
import 'dart:io';

import 'package:firebase_storage/firebase_storage.dart';
import 'package:get/get.dart';
import 'package:image_picker/image_picker.dart';
import 'package:permission_handler/permission_handler.dart';

class ImageUploadController extends GetxController {
  ImagePicker picker = ImagePicker();
  Rx<File> file = File("").obs;
  PermissionStatus? permissionStatus;
  RxBool isDownloading=false.obs;

  pickImage() async {
    await picker.pickImage(source: ImageSource.gallery).then((value) {
      log(value!.path.toString());
      file.value = File(value.path.toString());
      log(file.value.toString());
    });
    uploadPic();
  }

  FirebaseStorage storage = FirebaseStorage.instance;
  String dowurl = '';

  uploadPic() async {
    isDownloading.value=true;
    Reference ref = storage.ref().child('images/');
    UploadTask uploadTask = ref.putFile(file.value);

    uploadTask.whenComplete(() async {
      await ref.getDownloadURL().then((value) {
        log("============>${value}");
        dowurl=value.toString();
        isDownloading.value=false;
      });
    });
  }

  @override
  Future<void> onInit() async {
    permissionStatus = await Permission.storage.status;

    if (permissionStatus != PermissionStatus.granted) {
      PermissionStatus permissionStatus = await Permission.storage.request();
      permissionStatus = permissionStatus;
    }
    super.onInit();
  }
}
