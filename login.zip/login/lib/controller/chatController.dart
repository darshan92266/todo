import 'dart:developer';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/cupertino.dart';
import 'package:get/get.dart';
import 'package:login/models/chat_model.dart';

class ChatController extends GetxController {
  RxInt value = 5.obs;
  RxList<ChatModel> chatList = <ChatModel>[].obs;
  Rx<TextEditingController> messageController = TextEditingController().obs;

  Future<void> getChatData() async {
    try {
      await FirebaseFirestore.instance.collection("settings").get().then((value) async {
        chatList.clear();
        for (var element in value.docs) {
          ChatModel chatModel = ChatModel.fromJson(element.data());
          chatList.add(chatModel);
          log(chatModel.message.toString());
        }
      });
    } catch (e) {
      log("=======${e.toString()}");
    }
  }

  Future<void> setData() async {
    try {
      await FirebaseFirestore.instance.collection("settings").doc().set({"message": messageController.value.text, "isUser": true}).then((value) {
        messageController.value.clear();
        getChatData();
      });

    } catch (e) {
      log("=======${e.toString()}");
    }
  }

  @override
  void onInit() {
    getChatData();
    super.onInit();
  }
}
