import 'package:flutter/material.dart';

// ignore: must_be_immutable
class CustomTextFormField extends StatelessWidget {
  String hint;
  TextInputType keyboardType;
  int maxLength;
  TextEditingController controller;
  IconData? suffixIcon;

  CustomTextFormField({Key? key, required this.hint, required this.keyboardType, required this.maxLength, required this.controller, this.suffixIcon})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    return TextFormField(
        keyboardType: keyboardType,
        maxLength: maxLength,
        controller: controller,
        decoration: InputDecoration(
          hintText: hint,
          label: Text(hint),
        ));
  }
}
