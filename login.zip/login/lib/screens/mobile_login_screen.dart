import 'package:country_picker/country_picker.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:login/controller/mobile_login_controller.dart';
import 'package:login/widgets/text_field.dart';

class MobileLoginScreen extends StatelessWidget {
  const MobileLoginScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return GetX<MobileLoginController>(
        init: MobileLoginController(),
        builder: (controller) {
          return SafeArea(
            child: Scaffold(
              body: Column(
                children: [
                  ElevatedButton(
                    onPressed: () {
                      showCountryPicker(
                        context: context,
                        showPhoneCode: true,
                        onSelect: (Country country) {
                          if (kDebugMode) {
                            print('Select country: ${country.phoneCode}');
                            controller.countryCode.value = country.phoneCode;
                          }
                        },
                        countryListTheme: CountryListThemeData(
                          borderRadius: const BorderRadius.only(
                            topLeft: Radius.circular(40.0),
                            topRight: Radius.circular(40.0),
                          ),
                          inputDecoration: InputDecoration(
                            labelText: 'Search',
                            hintText: 'Start typing to search',
                            prefixIcon: const Icon(Icons.search),
                            border: OutlineInputBorder(
                              borderSide: BorderSide(
                                color: const Color(0xFF8C98A8).withOpacity(0.2),
                              ),
                            ),
                          ),
                          // Optional. Styles the text in the search field
                          searchTextStyle: const TextStyle(
                            color: Colors.blue,
                            fontSize: 18,
                          ),
                        ),
                      );
                    },
                    child: const Text('Select Country'),
                  ),
                  CustomTextFormField(
                    keyboardType: TextInputType.phone,
                    hint: 'Enter Mobile Number',
                    maxLength: 100,
                    controller: controller.mobileSignUpController.value,
                  ),
                  ElevatedButton(
                      onPressed: () {
                        controller.countryCode.value.toString().isEmpty
                            ? Get.snackbar("Please check value", "Please Select CountryCode")
                            : controller.mobileSignUpController.value.text.isEmpty
                                ? Get.snackbar("Please check value", "Please Enter Mobile number")
                                : controller.verifyPhoneNumber();
                      },
                      child: const Text("Submit")),
                  Text(controller.authStatus.value).marginAll(20),
                  controller.otpView.value
                      ? Column(
                          children: [
                            SizedBox(
                              width: MediaQuery.of(context).size.width * 0.5,
                              child: Padding(
                                padding: const EdgeInsets.all(8.0),
                                child: TextFormField(
                                  decoration: const InputDecoration(
                                    border: OutlineInputBorder(
                                      borderRadius: BorderRadius.all(
                                        Radius.circular(30),
                                      ),
                                    ),
                                  ),
                                  onChanged: (value) {
                                    controller.otp.value = value;
                                  },
                                ),
                              ),
                            ),
                            ElevatedButton(
                              onPressed: () {
                                controller.signIn(controller.otp.value.toString());
                              },
                              child: const Text(
                                'Submit',
                              ),
                            ),
                          ],
                        )
                      : const SizedBox(),
                ],
              ),
            ),
          );
        });
  }
}
