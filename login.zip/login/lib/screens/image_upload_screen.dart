import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:login/controller/image_upload_controller.dart';

class ImageUploadScreen extends StatelessWidget {
  const ImageUploadScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return GetBuilder<ImageUploadController>(
        init: ImageUploadController(),
        builder: (controller) {
          return SafeArea(
            child: Scaffold(
              body: Column(
                children: [
                  ElevatedButton(
                      onPressed: () {
                        controller.pickImage();
                      },
                      child: const Text("Upload Image")),
                 Obx(()=> SizedBox(
                    height: MediaQuery.of(context).size.width,
                    width: MediaQuery.of(context).size.width,
                    child: controller.isDownloading.value?const Center(child: CircularProgressIndicator()):controller.dowurl.isEmpty?null:Image.network(controller.dowurl),
                  ))
                ],
              ),
            ),
          );
        });
  }
}
