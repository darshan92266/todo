import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:get/get.dart';
import 'package:login/controller/home_controller.dart';
import 'package:login/screens/chat%20screen.dart';
import 'package:login/screens/email_login_screen.dart';
import 'package:login/screens/email_sign_screen.dart';
import 'package:login/screens/image_upload_screen.dart';
import 'package:login/screens/mobile_login_screen.dart';
import 'package:login/screens/payment_getway_screen.dart';
import 'package:login/screens/video_upload_screen.dart';

class HomeScreen extends StatelessWidget {
  const HomeScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return GetBuilder<HomeController>(
        init: HomeController(),
        builder: (controller) {
          return SafeArea(
            child: Scaffold(
              body: Column(
                children: [
                  ElevatedButton(
                      onPressed: () {
                        Get.to(const EmailLoginScreen());
                      },
                      child: const Text("Email Login")),
                  ElevatedButton(
                      onPressed: () {
                        Get.to(const EmailSignupScreen());
                      },
                      child: const Text("Email SignUp")),
                  ElevatedButton(
                      onPressed: () {
                        Get.to(const MobileLoginScreen());
                      },
                      child: const Text("Mobile Login")),
                  ElevatedButton(
                      onPressed: () {
                        Get.to(const PaymentGatewayScreen());
                      },
                      child: const Text("Payment Gateway")),
                  ElevatedButton(
                      onPressed: () {
                        Get.to(const ChatScreen());
                      },
                      child: const Text("Firebase Chat")),
                  ElevatedButton(
                      onPressed: () {
                        Get.to(const ImageUploadScreen());
                      },
                      child: const Text("Image Upload")),
                  ElevatedButton(
                      onPressed: () {
                        Get.to(const VideoUploadScreen());
                      },
                      child: const Text("Video Upload")),
                  Row(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      ElevatedButton(onPressed: controller.signInWithGoogle, child: SvgPicture.asset("assets/google_fill.svg")),
                      const SizedBox(
                        width: 20,
                      ),
                      ElevatedButton(onPressed: controller.getStoreVersion, child: SvgPicture.asset("assets/apple_fill.svg"))
                    ],
                  )
                ],
              ),
            ),
          );
        });
  }
}
