import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:login/controller/chatController.dart';

class ChatScreen extends StatelessWidget {
  const ChatScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return GetX<ChatController>(
        init: ChatController(),
        builder: (controller) {
          return SafeArea(
            child: Scaffold(
              body: Column(
                children: [
                  Flexible(
                    child: ListView.builder(
                      itemCount: controller.chatList.length,
                      shrinkWrap: true,
                      itemBuilder: (context, index) {
                        return Row(
                          mainAxisSize: MainAxisSize.min,
                          mainAxisAlignment: MainAxisAlignment.end,
                          crossAxisAlignment: CrossAxisAlignment.end,
                          children: [
                            Container(
                              margin: const EdgeInsets.all(5),
                              padding: const EdgeInsets.all(5),
                              decoration: const BoxDecoration(
                                  color: Colors.purple,
                                  borderRadius:
                                      BorderRadius.only(bottomLeft: Radius.circular(20), topLeft: Radius.circular(20), bottomRight: Radius.circular(20))),
                              child: Text(
                                controller.chatList[index].message.toString(),
                                style: const TextStyle(color: Colors.black),
                              ),
                            ),
                          ],
                        );
                      },
                    ),
                  ),
                  const SizedBox(height: 65)
                ],
              ),
              bottomSheet: Row(
                children: [
                  Container(
                    margin: const EdgeInsets.symmetric(horizontal: 10,vertical: 5),
                    width: MediaQuery.of(context).size.width * 0.8,
                    height: 55,
                    child: TextFormField(
                      controller: controller.messageController.value,
                      decoration: InputDecoration(
                        hintText: "Write massage hear",
                        border: OutlineInputBorder(borderRadius: BorderRadius.circular(20))
                      ),
                    ),
                  ),
                  InkWell(
                      onTap: () {
                        controller.setData();

                      },
                      child: const CircleAvatar(
                        child: Icon(Icons.send),
                      )),
                ],
              ),
            ),
          );
        });
  }
}
