import 'dart:developer';

import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:login/controller/payment_gateway_controller.dart';
import 'package:login/utils/preferences.dart';

class PaymentGatewayScreen extends StatelessWidget {
  const PaymentGatewayScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return GetBuilder<PaymentGatewayController>(
        init: PaymentGatewayController(),
        builder: (controller) {
          return SafeArea(
            child: Scaffold(
              body: Column(
                children: [
                  ElevatedButton(
                      onPressed: () async {
                        if (FirebaseAuth.instance.isNull) {
                          log("Login");
                        } else {
                          controller.isLogin.value = false;
                          Preferences.setBoolean(Preferences.isLogin, false);
                          await FirebaseAuth.instance.signOut();
                          Get.back();
                        }
                      },
                      child: const Icon(Icons.logout)),
                  TextButton(
                    child: const Text('Make Payment'),
                    onPressed: () async {
                      controller.stripeMakePayment(amount: '100');
                    },
                  ),
                ],
              ),
            ),
          );
        });
  }
}
