import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:login/controller/email_sign_up_controller.dart';
import 'package:login/widgets/text_field.dart';

class EmailSignupScreen extends StatelessWidget {
  const EmailSignupScreen({Key? key}) : super(key: key);
  @override
  Widget build(BuildContext context) {
    return GetBuilder<EmailSignUpController>(
        init: EmailSignUpController(),
        builder: (controller) {
          return Scaffold(
            appBar: AppBar(),
            body: Column(
              children: [
                CustomTextFormField(
                  keyboardType: TextInputType.emailAddress,
                  hint: 'Enter Email',
                  maxLength: 100,
                  controller: controller.emailSignUpController.value,
                ),
                CustomTextFormField(
                    keyboardType: TextInputType.visiblePassword, hint: 'Enter Password', maxLength: 18, controller: controller.passwordSignUpController.value),
                ElevatedButton(
                    onPressed: () {
                      controller.emailSignUpController.value.text.isEmpty
                          ? Get.snackbar("Please check value","Please Enter Email")
                          : controller.passwordSignUpController.value.text.isEmpty
                          ? Get.snackbar("Please check value","Please Enter password")
                          : controller.submit();
                    },
                    child: const Text("Submit"))
              ],
            ),
          );
        });
  }
}
