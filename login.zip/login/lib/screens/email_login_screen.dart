import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:login/controller/email_login_controller.dart';
import 'package:login/widgets/text_field.dart';

class EmailLoginScreen extends StatelessWidget {
  const EmailLoginScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return GetBuilder<EmailLoginController>(
        init: EmailLoginController(),
        builder: (controller) {
          return Scaffold(
            appBar: AppBar(),
            body: Column(
              children: [
                CustomTextFormField(
                  keyboardType: TextInputType.emailAddress,
                  hint: 'Enter Email',
                  maxLength: 100,
                  controller: controller.emailController.value,
                ),
                CustomTextFormField(
                    keyboardType: TextInputType.visiblePassword, hint: 'Enter Password', maxLength: 18, controller: controller.passwordController.value),
                ElevatedButton(
                    onPressed: () {
                      controller.emailController.value.text.isEmpty
                          ? Get.snackbar("Please check value","Please Enter Email")
                          : controller.passwordController.value.text.isEmpty
                              ? Get.snackbar("Please check value","Please Enter password")
                              : controller.submit();
                    },
                    child: const Text("Submit"))
              ],
            ),
          );
        });
  }
}
