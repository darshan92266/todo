import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:login/controller/video_upload_controller.dart';

class VideoUploadScreen extends StatelessWidget {
  const VideoUploadScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return GetBuilder<VideoUploadController>(
      init: VideoUploadController(),
      builder: (controller) {
        return SafeArea(
          child: Scaffold(
            body: Column(
              children: [
                ElevatedButton(onPressed: (){
                  controller.uploadToStorage();
                }, child: const Text("Upload Video"))
              ],
            ),
          ),
        );
      }
    );
  }
}
